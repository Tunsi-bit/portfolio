import java.time.*;
import java.time.temporal.ChronoUnit;
public class ContoCorrente
{

protected int codice_conto;
protected double saldo;
protected int numero_movimenti_conto;
protected double tasso_interesse;
LocalDate Data_apertura_conto;
public ContoCorrente(int codice_conto, double saldo, int numero_movimenti_conto, double tasso_interesse, LocalDate Data_apertura_conto)
{
    this.codice_conto=codice_conto;
    this.saldo=saldo;
    this.numero_movimenti_conto=numero_movimenti_conto;
    this.tasso_interesse=tasso_interesse;
    this.Data_apertura_conto=Data_apertura_conto;
}

public int getcodice_conto()
{
    return codice_conto;
}
public double getsaldo()
{
    return saldo;
}
public int getnumero_movimenti_conto()
{
    return numero_movimenti_conto;
}
public double gettasso_interesse()
{
    return tasso_interesse;
}
public LocalDate getData_apertura_conto()
{
    return Data_apertura_conto;
}

    public double interessi() {
        long giorni = ChronoUnit.DAYS.between(Data_apertura_conto, LocalDate.now());
        double anni = giorni / 365.0;
        return saldo * tasso_interesse * anni;
    }

    public void stampa() {
        System.out.println(codice_conto + " saldo: " + saldo);
    }
}