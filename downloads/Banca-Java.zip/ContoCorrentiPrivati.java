import java.time.*;

public class ContoCorrentiPrivati extends ContoCorrente
{

    private String codice_fiscale;
    private String nome;
    private String cognome;

    public ContoCorrentiPrivati(int codice_conto, double saldo, int numero_movimenti_conto, double tasso_interesse, LocalDate Data_apertura_conto, String codice_fiscale, String nome, String cognome)
    {
        super(codice_conto, saldo, numero_movimenti_conto, tasso_interesse,Data_apertura_conto);
        this.codice_fiscale=codice_fiscale;
        this.nome=nome;
        this.cognome=cognome;
    }

    public String getcodice_fiscale()
    {
        return codice_fiscale;
    }

    public String getnome()
    {
        return nome;
    }

    public String getcognome()
    {
        return cognome;
    }

     @Override
    public void stampa() 
    {
        super.stampa();
        System.out.println(nome + " " + cognome + ", Codice Fiscale: " + codice_fiscale);
    }

}