#ifndef RETE_H
#define RETE_H

#include <winsock2.h>
#include <iphlpapi.h>

// costanti
#define TUTTO_OK 0
#define ERRORE_MEMORIA 1
#define ERRORE_RECUPERO_RETE 2
#define ERRORE_NESSUNA_SCHEDA 3
#define ERRORE_LAYOUT 4

#define MAX_TESTO 256

// struttura dati rete
typedef struct {
    char suffissoDns[MAX_TESTO];
    char ipv6[MAX_TESTO];
    char ipv4[MAX_TESTO];
    char subnet[MAX_TESTO];
    char gateway[MAX_TESTO];
} InfoRete;

// funzioni logica rete
int prendiDatiRete(InfoRete *dati);

#endif
