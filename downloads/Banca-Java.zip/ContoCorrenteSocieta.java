import java.time.*;

public class ContoCorrenteSocieta extends ContoCorrente
{

    protected String partita_iva;
    protected String ragione_sociale;
    protected double fido;

    public ContoCorrenteSocieta(int codice_conto, double saldo, int numero_movimenti_conto, double tasso_interesse, LocalDate Data_apertura_conto, String partita_iva, String ragione_sociale, double fido)
    {
        super(codice_conto, saldo, numero_movimenti_conto, tasso_interesse,Data_apertura_conto);
        this.partita_iva=partita_iva;
        this.ragione_sociale=ragione_sociale;
        this.fido=fido;
    }

    public String getpartita_iva()
    {
        return partita_iva;
    }
    public String getragione_sociale()
    {
        return ragione_sociale;
    }
    public double getfido()
    {
        return fido;
    }
     public double getFidoResiduo() {
        return fido + saldo;
    }

    @Override
    public void stampa() {
        super.stampa();
        System.out.println(ragione_sociale + " | fido mancante : " + getFidoResiduo());
    }

}