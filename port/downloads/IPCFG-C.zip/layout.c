#include <stdio.h>
#include "librete.h"

/*
    Questa funzione riceve una struct con le informazioni di rete
    e le stampa a schermo in formato simile a ipconfig.
*/
int stampaIpconfig(InfoRete dati)
{
    printf("\n");
    printf("Configurazione IP di Windows\n");
    printf("\n\n");

    printf("Scheda Ethernet Ethernet:\n\n");

    // stampa dei dati recuperati dalla rete
    printf("   Suffisso DNS specifico per connessione: %s\n", dati.suffissoDns);
    printf("   Indirizzo IPv6 locale rispetto al collegamento . : %s\n", dati.ipv6);
    printf("   Indirizzo IPv4. . . . . . . . . . . . : %s\n", dati.ipv4);
    printf("   Subnet mask . . . . . . . . . . . . . : %s\n", dati.subnet);
    printf("   Gateway predefinito . . . . . . . . . : %s\n", dati.gateway);

    printf("\n");

    return TUTTO_OK;
}

/*
    Questa funzione gestisce la stampa degli errori.
    In base al codice ricevuto, mostra un messaggio diverso.
*/
int stampaErrore(int codice)
{
    printf("\nERRORE: ");

    // gestione degli errori tramite codice
    if (codice == ERRORE_MEMORIA)
        printf("Puntatore nullo in memoria\n");

    else if (codice == ERRORE_RECUPERO_RETE)
        printf("Impossibile recuperare i dati da Windows\n");

    else if (codice == ERRORE_NESSUNA_SCHEDA)
        printf("Nessuna scheda di rete trovata\n");

    else if (codice == ERRORE_LAYOUT)
        printf("Problema nella stampa a schermo\n");

    else
        printf("Errore sconosciuto\n");

    return codice;
}
