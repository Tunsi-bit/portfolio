import java.util.*;
import java.io.File;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.io.IOException;

public class Banca 
{
    ArrayList<ContoCorrente> lista = new ArrayList<>();
  
    public void inserisci(ContoCorrente c) 
    {
        lista.add(c);
    }
    
    public void stampaConti() 
    {
        for (ContoCorrente c : lista) 
        {
            c.stampa();
        }
    }

    public double totaleSaldi() 
    {
        double tot = 0;

        for (ContoCorrente c : lista) 
        {
            tot += c.getsaldo();
        }

        return tot;
    }
    
    public void contaContiPerTipo() 
    {
        int privati = 0;
        int societa = 0;

        for (ContoCorrente c : lista) 
        {
            if (c instanceof ContoCorrentiPrivati) privati++;
            if (c instanceof ContoCorrenteSocieta) societa++;
        }

        System.out.println("Privati: " + privati);
        System.out.println("Societa: " + societa);
    }

    public double totaleInteressi() 
    {

        double tot = 0;

        for (ContoCorrente c : lista) 
        {
            tot += c.interessi();
        }

        return tot;
    }

    public void contiInRosso() 
    {

        for (ContoCorrente c : lista) 
        {

            if (c instanceof ContoCorrenteSocieta soc) 
            {

                if (soc.getsaldo() < 0) 
                {
                    soc.stampa();
                }
            }
        }
    }
    
    public void stampaContiVecchi(int anni) 
    {

        for (ContoCorrente c : lista) {

            long giorni = ChronoUnit.DAYS.between(c.getData_apertura_conto(), LocalDate.now());
            int a = (int)(giorni / 365);

            if (a >= anni) 
            {
                c.stampa();
            }
        }
    }

    public void caricaPrivati(String file) 
    {

        try {

            Scanner sc = new Scanner(new File(file));

            while (sc.hasNextLine()) 
            {

                String[] d = sc.nextLine().split(",");

                lista.add(new ContoCorrentiPrivati(Integer.parseInt(d[0]), Double.parseDouble(d[1]), Integer.parseInt(d[2]), Double.parseDouble(d[3]), LocalDate.parse(d[4]), d[5], d[6], d[7]));
            }

            sc.close();

        } catch (IOException e) 
        {
            System.out.println("Errore privati: " + e);
        }
    }

    
    public void caricaSocieta(String file) 
    {
        try {

            Scanner sc = new Scanner(new File(file));
       
            while (sc.hasNextLine()) {

                String[] d = sc.nextLine().split(",");

                lista.add(new ContoCorrenteSocieta(Integer.parseInt(d[0]), Double.parseDouble(d[1]), Integer.parseInt(d[2]), Double.parseDouble(d[3]), LocalDate.parse(d[4]), d[5], d[6], Double.parseDouble(d[7])));
            }

            sc.close();

        } catch (IOException e) {
            System.out.println("Errore societa: " + e);
        }
    }
   
    public static void main(String[] args) {

        Banca b = new Banca();

        b.caricaPrivati("conti_privati.csv");
        b.caricaSocieta("conti_societa.csv");

        System.out.println("Conti:");
        b.stampaConti();

        System.out.println("totale saldi: " + b.totaleSaldi());

        b.contaContiPerTipo();

        System.out.println("interessi totali: " + b.totaleInteressi());

        System.out.println("Conti in rosso:");
        b.contiInRosso();

        System.out.println("Conti vecchi");
        b.stampaContiVecchi(3);
    }
}