#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <winsock2.h>
#include <iphlpapi.h>
#include "librete.h"

/*
    Funzione principale:
    recupera tutte le informazioni di rete dal sistema Windows
    e le salva dentro la struct InfoRete.
*/
int prendiDatiRete(InfoRete *dati)
{
    // array per metodo "base" (IPv4, subnet, gateway)
    IP_ADAPTER_INFO base[10];
    DWORD sizeBase = sizeof(base);

    // strutture per metodo "avanzato"
    PIP_ADAPTER_ADDRESSES lista = NULL;   // lista completa schede
    PIP_ADAPTER_ADDRESSES corrente = NULL; // puntatore per scorrere lista
    PIP_ADAPTER_UNICAST_ADDRESS unicast = NULL; // indirizzi singoli (IPv6 ecc.)

    DWORD sizeAdv = 15000;
    WSADATA wsadata;

    int i;

    // controllo sicurezza: puntatore valido
    if (dati == NULL)
        return ERRORE_MEMORIA;

    // inizializzo struct svuotando i campi
    strcpy(dati->suffissoDns, "");
    strcpy(dati->ipv6, "");
    strcpy(dati->ipv4, "");
    strcpy(dati->subnet, "");
    strcpy(dati->gateway, "");

    // avvio libreria di rete Windows (obbligatorio per socket)
    if (WSAStartup(MAKEWORD(2, 2), &wsadata) != 0)
        return ERRORE_RECUPERO_RETE;

    /*
        =========================
        METODO 1 (pi� semplice)
        =========================
        prende IPv4, subnet e gateway dalla prima scheda
    */
    if (GetAdaptersInfo(base, &sizeBase) == ERROR_SUCCESS)
    {
        strcpy(dati->ipv4, base[0].IpAddressList.IpAddress.String);
        strcpy(dati->subnet, base[0].IpAddressList.IpMask.String);
        strcpy(dati->gateway, base[0].GatewayList.IpAddress.String);
    }

    /*
        =========================
        METODO 2 (pi� completo)
        =========================
        usa GetAdaptersAddresses per dati avanzati (DNS, IPv6)
    */

    lista = (PIP_ADAPTER_ADDRESSES)malloc(sizeAdv);

    if (lista != NULL)
    {
        if (GetAdaptersAddresses(AF_UNSPEC, 0, NULL, lista, &sizeAdv) == ERROR_SUCCESS)
        {
            corrente = lista;

            // scorro tutte le schede di rete
            while (corrente != NULL)
            {
                /*
                    filtro:
                    - scheda attiva
                    - non loopback (non localhost)
                */
                if (corrente->OperStatus == IfOperStatusUp &&
                    corrente->IfType != IF_TYPE_SOFTWARE_LOOPBACK)
                {
                    /*
                        DNS suffix:
                        viene copiato solo la prima volta trovata
                    */
                    if (corrente->DnsSuffix != NULL &&
                        strlen(dati->suffissoDns) == 0)
                    {
                        for (i = 0;
                             corrente->DnsSuffix[i] != 0 &&
                             i < MAX_TESTO - 1;
                             i++)
                        {
                            dati->suffissoDns[i] =
                                (char)corrente->DnsSuffix[i];
                        }

                        dati->suffissoDns[i] = '\0';
                    }

                    /*
                        IPv6:
                        si prende dal primo indirizzo unicast disponibile
                    */
                    unicast = corrente->FirstUnicastAddress;

                    while (unicast != NULL)
                    {
                        if (unicast->Address.lpSockaddr->sa_family == AF_INET6 &&
                            strlen(dati->ipv6) == 0)
                        {
                            DWORD len = MAX_TESTO;

                            // converte indirizzo IPv6 in stringa leggibile
                            WSAAddressToStringA(
                                unicast->Address.lpSockaddr,
                                unicast->Address.iSockaddrLength,
                                NULL,
                                dati->ipv6,
                                &len
                            );
                        }

                        unicast = unicast->Next;
                    }
                }

                // passo alla prossima scheda
                corrente = corrente->Next;
            }
        }

        // libero memoria allocata
        free(lista);
    }

    // chiusura libreria socket
    WSACleanup();

    return TUTTO_OK;
}
