#include <stdio.h>
#include <stdlib.h>


int BubbleSort()
{
    int i, scambio, j, errore, dim;

    printf("inserire la dimensione dell'array\t");
    scanf("%d", &dim);
    int array[dim];
    errore=0;

    for(i=0; i<dim; i++)
    {
        printf("inserire gli elementi desiderati nell'array\t");
        scanf("%d", &array[i]);
    }
    printf("l'array composto � il seguente:\n");
    for(i=0; i<dim; i++)
    {
        printf("%d\t", array[i]);
    }
    printf("\n");

    for(i=0; i<dim-1; i++)
    {
        for(j=0; j<dim-i-1; j++)
        {
            if(array[j]>array[j+1])
            {

                scambio=array[j];
                array[j]=array[j+1];
                array[j+1]=scambio;
                errore++;
            }
        }
    }
    printf("l'array ordinato � il seguente:");
    for(i=0; i<dim; i++)
    {
        printf("%d\t", array[i]);
    }
    printf("\n");

    printf("sono stati effettuati %d scambi", errore);
    return 0;
}
int main()
{
    BubbleSort();
}
