#include <stdio.h>
#include "librete.h"
// Percentuale codice non capito: 35%
int main()
{
    InfoRete dati;
    int errore;

    errore = prendiDatiRete(&dati);
    if (errore != TUTTO_OK)
    {
        stampaErrore(errore);
        return errore;
    }

    errore = stampaIpconfig(dati);
    if (errore != TUTTO_OK)
    {
        stampaErrore(errore);
        return errore;
    }

    return TUTTO_OK;
}
//              N
